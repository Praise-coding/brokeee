"use client"
import React from 'react'
import {Dummydata2 as AdminCryptoAddress} from "@/app/User/dummyData";
import DepositForm from "@/app/Admin/Deposit/DepositForm";


function DepositWalletAddressAndBalanceCards({cardName, balanceOrWalletAddress, amOrAdd, copy}: {
    cardName: string,
    copy?: boolean,
    balanceOrWalletAddress: string,
    amOrAdd?: boolean
}) {

    return (
        <div className="grid gap-[24px] sm:mt-[14px] mt-[15px] grid-cols-1">
            <div className="grid grid-cols-1 h-fit gap-[12px] sm:gap-[22px]">
                {Object.entries(AdminCryptoAddress).map((data, key) => {
                    return (
                        <React.Fragment key={key}>
                            <DepositWalletAddressAndBalanceCards amOrAdd={true} copy={true} cardName={data[0]}
                                             balanceOrWalletAddress={data[1].toString()}/>
                        </React.Fragment>
                    )
                })}
                <div className="font-poppins sm:text-[16px] text-[14px]  text-white mt-[17px] text-center">
                    To deposit, please choose the payment method at the Payment Methods panel and make the payment.
                    After completing the payment come back here and fill the deposit notification form.
                </div>
            </div>
            <div className="bg-[#1B2028]  rounded-[15px] py-[20px] sm:py-[50px] px-[15px] sm:px-[31px]">
                <div>
                    <DepositForm/>
                </div>
            </div>
        </div>
    )
}

export default DepositWalletAddressAndBalanceCards
