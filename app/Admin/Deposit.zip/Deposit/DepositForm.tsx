import React, {ChangeEvent, useState} from 'react'
import UploadIconSvg from "@/app/components/ui/UploadIconSvg";
import InputTemp from "@/app/components/ui/InputTemp";
import SelectTemp from "@/app/components/ui/SelectInputTemp";
import {useForm} from "react-hook-form";
import Image from "next/image";
import Loading from "@/app/(auth)/loading";
import {submitForm} from "@/app/User/Deposit/SubmitForm";
import {useSession} from "next-auth/react";
import {Toaster} from "@/app/(auth)/formUi/Toast";


function DepositForm() {

    const {register, handleSubmit, getValues, formState: {errors}} = useForm({})
    const options = ["Bitcoin", "Ethereum", "Tether"];
    const [image, setImage] = useState<string>("/empty");
    const [rawImageFile, setRawImageFile] = useState<File>();
    const [loading, setLoading] = useState(false)
    const {data} = useSession()




    const formSubmitter = async () => {
        if (data?.["user"]?.["UserBalance"]?.["AllowWithdrawal"] == 0 || data?.["user"]?.["UserBalance"]?.["AllowDeposit"] == 0) {
            Toaster("error", "You cannot make this transaction")
            return;
        }

        await submitForm(getValues, image, handleSubmit, setLoading, rawImageFile)
    }
    return (
        <>
            {loading && <Loading/>}
            <form onSubmit={async (e) => {
                e.preventDefault()
                await formSubmitter()
            }} className="grid gap-[20px] sm:gap-[30px]">
                <InputTemp
                    type={"number"}
                    errors={errors}
                    inputName={'Amount'}
                    placeholder={"Amount In Dollars ($)"}
                    inputChange={register}/>
                <InputTemp
                    type={"number"}
                    errors={errors}
                    inputName={'Amount'}
                    placeholder={"Amount In Dollars ($)"}
                    inputChange={register}/>
                <div>
                    <button
                        className="bg-[#5570F1] cursor-pointer font-poppins text-[14px] text-white w-full rounded-[12px] h-[47px]">
                        Submit
                    </button>
                </div>
            </form>


        </>
    )
}

export default DepositForm
